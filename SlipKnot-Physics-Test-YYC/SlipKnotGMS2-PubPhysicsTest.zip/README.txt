First public build of SlipKnot loll

Mainly just a physics test meaning no ui, collectables, etc.

Sorry about the small map btw :P

Everything is subject to change

Lmk what I can improve and shit in the issues tab lol

Ty's Controls:

Arrow keys - Movement
Z - Jump
X - Boost
C - Slam
V - Air Dash (legit like celeste's)